import React from 'react';
import ReactDOM from 'react-dom';
import './App.css';

function Login()
{
    return(
    <div className="logindiv">
        <label className="logintitle">Login</label>
        <br/>
        <input type="text" name="username" placeholder="User Name" className="logintext"/>
        <br/>
        <input type="password" name="password" placeholder="Password" className="logintext"/>
        <br/>
        <input type="submit" name="submit" className="loginbutton" />
        <br/>
        <br/>
    </div>
    );
}

export default Login;