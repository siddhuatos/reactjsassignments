import React from 'react';
import ReactDOM from 'react-dom';
import './App.css';

function Employee()
{
    return(
    <div className="employeediv">
<div>
   <label className="employeeheader">Id</label>
   <label className="employeeheader">Name</label>
   <label className="employeeheader">Designation</label>
</div>
<div>
<label className="employeedetalis">1</label>
<label className="employeedetalis">ABC</label>
<label className="employeedetalis">Developer</label>
</div>
<div>
<label className="employeedetalis">2</label>
<label className="employeedetalis">XYZ</label>
<label className="employeedetalis">Manager</label>
</div>

    </div>
    );
}

export default Employee;