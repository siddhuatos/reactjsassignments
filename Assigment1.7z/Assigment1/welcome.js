import React from 'react';
import ReactDOM from 'react-dom';

function Welcome(props)
{
    return(
    <h1>Welcome to my App {props.username}</h1>
    );
}

export default Welcome;
